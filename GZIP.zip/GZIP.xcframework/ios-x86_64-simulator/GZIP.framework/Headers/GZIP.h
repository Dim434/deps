#import <Foundation/Foundation.h>

//! Project version number for GZIP.
FOUNDATION_EXPORT double GZIPVersionNumber;

//! Project version string for GZIP.
FOUNDATION_EXPORT const unsigned char GZIPVersionString[];

#import <GZIP/NSData+GZIP.h>
